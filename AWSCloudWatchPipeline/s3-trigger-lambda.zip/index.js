const AWS = require('aws-sdk');
const codepipeline = new AWS.CodePipeline();

exports.handler = async (event) => {
  const jobId = event.Records[0].s3.object.key;
  const params = {
    name: 'app-pipeline' // CodePipeline name
  };
  
  try {
    const data = await codepipeline.startPipelineExecution(params).promise();
    console.log(`Pipeline started successfully: ${data}`);
  } catch (error) {
    console.error(`Pipeline execution failed: ${error}`);
    throw error;
  }
  
  return `Pipeline execution started with job ID: ${jobId}`;
};